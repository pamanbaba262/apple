<h1 align="center">Holograph Building Bridger</h1>

<h2>About the bot</h2>
Bot for bridging new holograph nft Building - https://app.holograph.xyz/ </br>


* Instruction and settings in config.py

* Private keys in  keys.txt </br>

* Need moralis api key - https://admin.moralis.io/settings#secret-keys
 </br>


<h2>Working modes</h2>

1. Bridge from a certain network to a certain network </br>
2. NFT search by networks and bridge to a random/selected network </br>


<h2>donate</h2> evm 0xFD6594D11b13C6b1756E328cc13aC26742dBa868
<h2>donate</h2> trc20 TMmL915TX2CAPkh9SgF31U4Trr32NStRBp

<h2>тг</h2> https://t.me/iliocka
